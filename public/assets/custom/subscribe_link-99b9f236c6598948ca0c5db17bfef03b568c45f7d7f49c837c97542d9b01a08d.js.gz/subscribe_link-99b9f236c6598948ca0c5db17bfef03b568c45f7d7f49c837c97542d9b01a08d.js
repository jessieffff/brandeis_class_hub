document.addEventListener("turbo:load", function () {
    let createalink = document.querySelector("#subscribe");
    createalink.addEventListener("click", function(createalink) {
    window.location.href = document.querySelector("textarea").value;
   });
});
