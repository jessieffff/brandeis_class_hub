  // function addtext() {
  //     window.location = document.querySelector("textarea").value;
  // }



   window.addtext = function() { window.location = document.querySelector("textarea").value; };
