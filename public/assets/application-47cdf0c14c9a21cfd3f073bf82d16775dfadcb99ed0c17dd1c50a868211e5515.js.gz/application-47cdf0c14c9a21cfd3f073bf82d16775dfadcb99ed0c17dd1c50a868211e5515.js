// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import "controllers"
import "custom/menu"
import "custom/new_event"
import "custom/subscribe_link"
//= require bootstrap-datepicker;
